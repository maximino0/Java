//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.nucleo;


import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.regras.Utils;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Jogador {
    private final String player1;
    private List<Carta> carta;
    private int soma;
    private int pontuacao;

    public Jogador(String nome) {
        this.player1 = nome;
        this.carta = new ArrayList<>();
        this.soma = 0;
        this.pontuacao = 0;
    }
    public int getpontuacao(){return this.pontuacao;}
    public void setpontuacao(int nova_pontuacao){this.pontuacao=nova_pontuacao;}
    public String getjogador() {
        return this.player1;
    }

    public void limparCarta() {
        this.carta = new ArrayList<>();
    }

    public void setCarta(Carta aux) {
        this.carta.add(aux);
    }

    public List<Carta> getCarta() {
        return this.carta;
    }

    public int getSoma() {
        return this.soma;
    }

    public void setSoma(int aux) {
        this.soma = aux;
    }

    public String toString() {
        return "Jogador{player1='" + this.player1 + this.carta + "'}";
    }

    public static List<Jogador> criar_Jogadores() {
        Scanner input = new Scanner(System.in);
        List<Jogador> jogadores = new ArrayList<>();
        int quantidade_de_jogadores;
        Utils util = new Utils();
        System.out.println("Você quer jogar contra a banca? S/N");
        if(input.nextLine().toUpperCase().charAt(0)=='S'){
            jogadores.add(new JogadorIA());
        }
        do{
            System.out.println("Quantos Jogadores vão entrar: ");
            try{
                quantidade_de_jogadores = Integer.parseInt(input.nextLine());
            }catch(Exception e){
                quantidade_de_jogadores = 0;
            }
        }while(!util.entrada_maior_que(quantidade_de_jogadores,1-jogadores.size(),"É impossível jogar com essa quantidade de jogadores.\n Reescreva a quantidade de jogadores:"));

        int jogadoria=jogadores.size();
        for(int entrada_jog = jogadores.size(); entrada_jog < quantidade_de_jogadores+jogadoria; ++entrada_jog) {
            System.out.println("Qual o nome do " + (entrada_jog + 1) + "° jogador:");
            String nome;
            do{
                nome = input.nextLine();
            }while(!util.entrada_maior_que(nome.length(),1,"Não existe esse nome.\n Reescreva o nome:"));
            Jogador jogador = new Jogador(nome);
            jogadores.add(jogador);
        }

        return jogadores;
    }
    public static void limpar_Pontuacao(List<Jogador> jogadores) {
        for(Jogador jogador : jogadores) {
            jogador.setpontuacao(0);

        }

    }
    public static void limpar_Mao(List<Jogador> jogadores) {
        for(Jogador jogador : jogadores) {
            jogador.limparCarta();

        }

    }
}
