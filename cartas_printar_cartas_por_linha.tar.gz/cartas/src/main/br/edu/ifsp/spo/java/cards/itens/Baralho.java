//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.itens;

import br.edu.ifsp.spo.java.cards.App;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baralho {
    private final List<Carta> cartas = new ArrayList<>();

    public Baralho() {
        for(Naipe suit : Naipe.values()) {
            for(Valor rank : Valor.values()) {
                this.cartas.add(new Carta(suit, rank));
            }
        }

        Collections.shuffle(this.cartas);
    }

    public Carta tirarCarta() {
        return this.cartas.removeFirst();
    }

    public int cartasRestantes() {
        return this.cartas.size();
    }

    public String toString() {
        return "Deck{cards=" + this.cartasRestantes() + "}";
    }

    public List<Carta> getCards() {
        return this.cartas;
    }

    public String MostrarCartas(List<Carta> cartas) {
        var linhas = new String[7];
        var linhaAtual = -1;
        int contador = 0;
        String resposta = "";
        while (contador < cartas.size()) {
            int regra = 1+contador;
            if (regra>cartas.size()){regra=cartas.size();}
            for (Carta carta : cartas.subList(contador,regra)) {
                var caminhoCompleto = String.format(
                        "/cards/%s/%s.txt",
                        carta.naipe().toString(),
                        carta.valor().toString()
                );
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(App.class.getResourceAsStream(caminhoCompleto)))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        linhaAtual += 1;
                        if (linhas[linhaAtual] == null) {
                            linhas[linhaAtual] = line;
                        } else {
                            linhas[linhaAtual] = linhas[linhaAtual] + "   " + line;
                        }
                    }
                    linhaAtual = -1;

                } catch (IOException exception) {
                    System.out.println("IOException: " + exception.getMessage());
                }
            }
            resposta+="\n";
            for (var linha : linhas) {
                resposta += "\n" + linha;
            }
            contador=regra;
        }
        return resposta;
    }
}
