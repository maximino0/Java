
package br.edu.ifsp.spo.java.cards;

import br.edu.ifsp.spo.java.cards.itens.Baralho;
import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.nucleo.Jogo;

import java.io.IOException;
import java.io.InputStream;
import java.nio.Buffer;
import java.sql.SQLOutput;

public class App {
    public App() {
    }

    public static void main(String[] args) {
        Jogo jogo = new Jogo();
        jogo.Jogo();

    }
}
