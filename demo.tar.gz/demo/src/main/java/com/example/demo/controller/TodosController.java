package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

record Todo(String texto, boolean concluido){ }
record TodoForm(String texto){ }

inal class Todo{
    private final int id;
    private final String texto;
}


@Controller
public class TodosController{
        List<Todo> todolist = new ArrayList<>(Arrays.asList(
                new Todo(1,"Fazer pastel", false),
                new Todo(2,"Comer o pastel ", false),
                new Todo(3,"Amassar no Hogwarts Legacy", false)
        ));
        @GetMapping("/todos")
        public String index(Model model){

            model.addAttribute("todolist",todolist);
            model.addAttribute("todoform",new TodoForm(""));
            return "todo/todo.html";
        }
        @PostMapping("/todos")
        public String create(Model model, TodoForm form){
            if (!form.texto().isEmpty())
                todolist.add(new Todo(form.texto(), false));
            return "redirect:/todos";
        }
        @GetMapping("/todos/{id}")
        public String update(@PathVariable("id") int id, Model model){
            var todoItem = todolist.stream().filter(todo -> todo.id == id).findFirst();
        }
}
