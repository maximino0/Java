//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.itens;

import br.edu.ifsp.spo.java.cards.App;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Baralho {
    private final List<Carta> cartas = new ArrayList<>();

    public Baralho() {
        for(Naipe suit : Naipe.values()) {
            for(Valor rank : Valor.values()) {
                this.cartas.add(new Carta(suit, rank));
            }
        }

        Collections.shuffle(this.cartas);
    }

    public Carta tirarCarta() {
        return this.cartas.removeFirst();
    }

    public int cartasRestantes() {
        return this.cartas.size();
    }

    public String toString() {
        return "Deck{cards=" + this.cartasRestantes() + "}";
    }

    public List<Carta> getCards() {
        return this.cartas;
    }

    public String MostrarCartas(List<Carta> cartas) {
        String[] linhas = new String[7];
        Arrays.fill(linhas,"");

        int contador_de_cartas =0;
        String resposta = "";
        int cartas_por_linha=5;
            for (Carta carta : cartas) {
                var caminhoCompleto = String.format(
                        "/cards/%s/%s.txt",
                        carta.naipe().toString(),
                        carta.valor().toString()
                );
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(App.class.getResourceAsStream(caminhoCompleto)))) {
                    String line;
                    var linhaAtual = 0;
                    while ((line = reader.readLine()) != null && linhaAtual<7) {
                        linhas[linhaAtual] += line+ "   " ;
                        linhaAtual ++;
                    }
                    contador_de_cartas+=1;
                } catch (IOException exception) {
                    System.out.println("IOException: " + exception.getMessage());
                }
                if(contador_de_cartas==cartas_por_linha){
                    for (String linha : linhas){
                        resposta += "\n" + linha;
                    }
                    Arrays.fill(linhas,"");
                    contador_de_cartas=0;
                }
            }
            for(String linha :linhas){
                resposta += "\n" + linha;
            }
        return resposta;
    }
}
