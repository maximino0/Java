//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.nucleo;

import br.edu.ifsp.spo.java.cards.itens.Baralho;
import br.edu.ifsp.spo.java.cards.regras.Pontuador;
import br.edu.ifsp.spo.java.cards.regras.Utils;
import br.edu.ifsp.spo.java.cards.ui.Ui;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Jogo {
    Baralho baralho = new Baralho();
    Pontuador pontuador = new Pontuador();
    Utils util = new Utils();
    List<Jogador> jogadores = new ArrayList<>();
    int soma = 0;
    Ui ui = new Ui();
    public void Jogo() {

            do {
                int rodada = util.rodadas();
                for (int i = 0; i <rodada ; i++) {
                    baralho = new Baralho();
                    if (jogadores.size() < 2) {
                        jogadores = Jogador.criar_Jogadores();
                    }
                    ui.rodada_jogada(i);
                    Jogador.limpar_Mao(jogadores);
                    util.dar_Carta(jogadores, baralho);

                    for (Jogador jogador : jogadores) {
                        do {
                            soma = 0;
                            util.setar_Soma(jogador, soma);
                            if (pontuador.verificar_mao(jogador.getSoma(), jogador)) {
                                break;
                            }
                        } while (!util.comprar_Carta(jogador.getSoma(), jogador, baralho, jogadores));
                    }
                    util.winner(jogadores);
                }
            }while (!util.jogar_novamente(jogadores));
    }
}
