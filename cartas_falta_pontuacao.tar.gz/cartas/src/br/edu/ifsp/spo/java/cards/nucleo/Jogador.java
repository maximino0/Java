//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.nucleo;

import br.edu.ifsp.spo.java.cards.itens.Carta;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Jogador {
    private final String player1;
    private List<Carta> carta;
    private int soma;
    private int pontuacao;

    public Jogador(String nome, List<Carta> carta, int soma, int pontuacao) {
        this.player1 = nome;
        this.carta = carta;
        this.soma = soma;
        this.pontuacao = pontuacao;
    }
    public int getpontuacao(){return this.pontuacao;}
    public void setpontuacao(int nova_pontuacao){this.pontuacao=nova_pontuacao;}
    public String getjogador() {
        return this.player1;
    }

    public void limparCarta() {
        this.carta = new ArrayList<>();
    }

    public void setCarta(Carta aux) {
        this.carta.add(aux);
    }

    public List<Carta> getCarta() {
        return this.carta;
    }

    public int getSoma() {
        return this.soma;
    }

    public void setSoma(int aux) {
        this.soma = aux;
    }

    public String toString() {
        return "Jogador{player1='" + this.player1 + this.carta + "'}";
    }

    public static List<Jogador> criar_Jogadores() {
        Scanner input = new Scanner(System.in);
        List<Jogador> jogadores = new ArrayList();
        System.out.println("Quantos Jogadores vão entrar: ");
        int quantidade_de_jogadores = input.nextInt();
        input.nextLine();

        for(int entrada_jog = 0; entrada_jog < quantidade_de_jogadores; ++entrada_jog) {
            System.out.println("Qual o nome do " + (entrada_jog + 1) + "° jogador:");
            String nome = input.nextLine();
            List<Carta> cartas = new ArrayList();
            Jogador jogador = new Jogador(nome, cartas, 0,0);
            jogadores.add(jogador);
        }

        return jogadores;
    }

    public static void limpar_Mao(List<Jogador> jogadores) {
        for(Jogador jogador : jogadores) {
            jogador.limparCarta();
        }

    }
}
