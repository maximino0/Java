package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
import java.util.List;

public class Rodada {
    public void pontuacao(List<Jogador> jogadores){
        jogadores.sort((Jogador jogador1, Jogador jogador2) -> Integer.compare(jogador2.getSoma(),jogador1.getSoma()));
        if (jogadores.get(0).getSoma()==21){
            jogadores.get(0).setpontuacao(jogadores.get(0).getSoma()+30);
//            if(jogadores.size()==3){
//                jogadores.get(1).setpontuacao();
//            }
//            arrumar um jeito de criar pontuação para diferentes jogadores e seguindo a verificação caso ele exploda o limite
//            se ele explodir a pontuação é zerada, e só é possivel zerar se explodir.
        }
    }
}
