//package br.edu.ifsp.spo.java.cards.nucleo;
//import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
//public class JogadorIA extends Jogador{
//    public jogadorIA(){
//        super(nome:"HAL-9000");
//    }
//    public acao_JogadorIA(int pontos){
//        return pontos>=18;
//    }
//}
