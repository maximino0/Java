//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.itens;

public class Carta {
    private final Naipe naipe;
    private final Valor valor;

    public Carta(Naipe naipe, Valor valor) {
        this.naipe = naipe;
        this.valor = valor;
    }

    public Naipe getNaipe() {
        return this.naipe;
    }

    public Valor getValor() {
        return this.valor;
    }

    public String toString() {
        return this.getValor() + " de " + this.getNaipe();
    }

    public boolean equals(Object o) {
        if (o != null && this.getClass() == o.getClass()) {
            Carta carta = (Carta)o;
            return this.naipe == carta.naipe && this.valor == carta.valor;
        } else {
            return false;
        }
    }
}
