package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
import java.util.List;

public class Rodada {
    public void pontuacao(List<Jogador> jogadores) {
        jogadores.sort((Jogador jogador1, Jogador jogador2) -> Integer.compare(jogador2.getSoma(), jogador1.getSoma()));
        int aux = 1;
        for (Jogador jogador : jogadores) {
            if (jogador.getSoma() == 21) {
                jogador.setSoma(30);
            }
            if (aux == 3) {
                break;
            }
            aux++;
        }
        for (int i = condicao_pontuacao(jogadores.size()); i < jogadores.size(); i++) {
            if (jogadores.get(i).getSoma() != -5 && jogadores.get(i).getSoma() != jogadores.get(condicao_pontuacao(jogadores.size())).getSoma()) {
                jogadores.get(i).setSoma(0);
            }
        }
        for (Jogador jogador : jogadores) {
            jogador.setpontuacao(jogador.getpontuacao()+jogador.getSoma());
        }
    }
    public int condicao_pontuacao(int entrada){
        if(entrada == 4 | entrada == 3){
            return 1;
        } else if (entrada >= 5) {
            return 2;
        } else {
            return 0; // valor padrão para outros casos, se necessário
        }
    }
}
