package br.edu.ifsp.spo.java.cards.regras;

public class BaralhoTest {
}
