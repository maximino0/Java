package br.edu.ifsp.spo.java.cards.nucleo;
import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
public class JogadorIA extends Jogador{

    public JogadorIA(){super("Banca");}

    public char decidir(int pontos){
        return pontos<18? 'S': 'N';
    }
}
