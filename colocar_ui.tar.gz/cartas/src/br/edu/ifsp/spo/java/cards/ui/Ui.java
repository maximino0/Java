package br.edu.ifsp.spo.java.cards.ui;

import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.nucleo.Jogador;

import java.util.List;

public class Ui {
    public void comprar_Carta(Jogador jogador, int soma){
        System.out.println(jogador.getjogador() + ", a soma das suas cartas é: " + soma + " pois você tem " + printar_Cartas(jogador.getCarta()) + ".\n Deseja comprar mais uma carta? S/N");
    }
    public String printar_Cartas(List<Carta> cartas){
        String resultado = "";
        for (Carta carta : cartas){
            resultado += " \n " + carta.toString() ;
        }
        return resultado;
    }
    public void tirar_Carta(Carta carta){
        System.out.println("Você tirou a carta: " + carta);
    }
}
