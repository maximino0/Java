//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.itens.Baralho;
import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
import br.edu.ifsp.spo.java.cards.ui.Ui;

import java.util.List;
import java.util.Scanner;

public class Utils {
    Pontuador pontuador = new Pontuador();
    Scanner input = new Scanner(System.in);
    Ui ui = new Ui();

    public void setar_Soma(Jogador jogador, int soma) {
        for(Carta valor : jogador.getCarta()) {
            soma = pontuador.valoresVinteEUm(valor.getValor(), soma);
            jogador.setSoma(soma);
        }

    }

    public boolean comprar_Carta(int soma, Jogador jogador, Baralho baralho, List<Jogador> jogadores) {
        ui.comprar_Carta(jogador,soma);
        String comprar = input.nextLine().toUpperCase();
        char resp = comprar.charAt(0);
        take_Time(1);
        if (resp == 'S') {
            Carta carta_tirada = baralho.tirarCarta();
            ui.tirar_Carta(carta_tirada);
            take_Time(1);
            jogador.getCarta().add(carta_tirada);
            return false;
        } else {
            String resposta = jogador.getjogador() + " a soma final das suas cartas é: " + soma;
            if (jogador != jogadores.get(jogadores.size() - 1)) {
                resposta = resposta + "\n Vez do próximo jogador."; //próximo jogador
            }

            System.out.println(resposta); //resposta
            take_Time(2);
            jogador.setSoma(soma);
            return true;
        }
    }

    public void take_Time(int valor) {
        try {
            Thread.sleep((long)(valor * 1000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public boolean winner(List<Jogador> jogadores) {
        int maior = 0;
        String resposta_final = "";

        for(Jogador jogador : jogadores) {
            if (jogador.getSoma() == maior && jogador.getSoma() > 0) {
                resposta_final += ", Mas o jogador " + jogador.getjogador() + " também ganhou com " + maior + " pontos";
            } else if (jogador.getSoma() > maior) {
                maior = jogador.getSoma();
                resposta_final = "O jogador " + jogador.getjogador() + " ganhou com " + maior + " pontos";
            }else if (jogadores.stream().allMatch(j -> j.getSoma() == 0)){
                resposta_final = "Todos os jogadores estouraram";
            }
        }

        resposta_final = resposta_final + ".";
        System.out.println(resposta_final);
        System.out.println("Você deseja jogar outra vez? S/N");
        String entrada = input.nextLine().toUpperCase();
        char resposta_jogar_novamente = entrada.charAt(0);
        if (resposta_jogar_novamente != 'S') {
            System.out.println("Ok, jogo finalizado.");
            return true;
        } else {
            System.out.println("Você deseja jogar com os mesmos jogadores: S/N \n");
            entrada = input.nextLine().toUpperCase();
            char resposta_para_os_mesmos_jogadores = entrada.charAt(0);
            if (resposta_para_os_mesmos_jogadores != 'S') {
                jogadores.clear();
            }

            return false;
        }
    }

    public void dar_Carta(List<Jogador> jogadores, Baralho baralho) {
        for(Jogador jogador : jogadores) {
            Carta cartas_iniciais = baralho.tirarCarta();
            jogador.setCarta(cartas_iniciais);
            cartas_iniciais = baralho.tirarCarta();
            jogador.setCarta(cartas_iniciais);
        }

    }

}
