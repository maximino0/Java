//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.ui;

import br.edu.ifsp.spo.java.cards.nucleo.Jogo;

public class App {
    public App() {
    }

    public static void main(String[] args) {
        Jogo jogo = new Jogo();
        jogo.Jogo();
    }
}
