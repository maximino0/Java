//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.itens;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baralho {
    private final List<Carta> cartas = new ArrayList();

    public Baralho() {
        for(Naipe suit : Naipe.values()) {
            for(Valor rank : Valor.values()) {
                this.cartas.add(new Carta(suit, rank));
            }
        }

        Collections.shuffle(this.cartas);
    }

    public Carta tirarCarta() {
        return (Carta)this.cartas.remove(0);
    }

    public int cartasRestantes() {
        return this.cartas.size();
    }

    public String toString() {
        return "Deck{cards=" + this.cartasRestantes() + "}";
    }

    public List<Carta> getCards() {
        return this.cartas;
    }
}
