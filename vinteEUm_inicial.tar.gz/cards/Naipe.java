package br.edu.ifsp.spo.java.cards;

public enum Naipe {
    COPAS, OUROS, PAUS, ESPADAS;
}
