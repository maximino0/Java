package br.edu.ifsp.spo.java.cards;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class App {

    public static void main(String[] args) {

        Baralho baralho = new Baralho();
        Jogo jogo = new Jogo();
        jogo.Jogo();

    }
}