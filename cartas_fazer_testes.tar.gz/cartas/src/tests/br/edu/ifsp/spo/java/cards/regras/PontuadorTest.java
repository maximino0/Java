package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.itens.Carta;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PontuadorTest {

    @Test
    void verificarMaoNula() {
        Pontuador pontuador = new Pontuador();
        List<Carta> cartas = null;
        var pontuacao_obtida = pontuador.pontuacao(cartas);
        assertEquals(0,pontuacao_obtida);
    }

//    @Test
//    void verificar_mao() {
//        Pontuador pontuador = new Pontuador();
//    }
}