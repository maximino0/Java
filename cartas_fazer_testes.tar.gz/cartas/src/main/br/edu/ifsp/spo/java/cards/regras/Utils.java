//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.itens.Baralho;
import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
import br.edu.ifsp.spo.java.cards.nucleo.JogadorIA;
import br.edu.ifsp.spo.java.cards.ui.Ui;
import java.util.List;
import java.util.Scanner;

public class Utils {
    Pontuador pontuador = new Pontuador();
    Scanner input = new Scanner(System.in);
    Ui ui = new Ui();
    public void setar_Soma(Jogador jogador, int soma) {
        jogador.setSoma(pontuador.pontuacao(jogador.getCarta()));
    }

    public boolean comprar_Carta(int soma, Jogador jogador, Baralho baralho, List<Jogador> jogadores) {
        char resp;
        if (jogador instanceof JogadorIA ia){
            ui.comprar_Carta(jogador, soma);
            resp = ia.decidir(jogador.getpontuacao());
        }else {
            ui.comprar_Carta(jogador, soma);
            String comprar = input.nextLine().toUpperCase();
            resp = comprar.charAt(0);
            take_Time(1);
        }
        if (resp == 'S') {
            Carta carta_tirada = baralho.tirarCarta();
            ui.tirar_Carta(carta_tirada,jogador);
            take_Time(1);
            jogador.getCarta().add(carta_tirada);
            return false;
        } else {
            String resposta = ui.soma_final(jogador, soma);
            if (jogador != jogadores.getLast()) {
                resposta = ui.passar_Vez(resposta); //próximo jogador
            }

            System.out.println(resposta); //resposta
            take_Time(2);
            jogador.setSoma(soma);
            return true;
        }
    }

    public void take_Time(int valor) {
        try {
            Thread.sleep((long)(valor * 1000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public void winner(List<Jogador> jogadores) {
        int maior = 0;
        String resposta_final = "Todos os jogadores perderam";
        for (Jogador jogador : jogadores) {
            if (jogador.getpontuacao() == maior && jogador.getpontuacao() > 0) {
                resposta_final = ui.empate(jogador, maior, resposta_final);
            } else if (jogador.getpontuacao() > maior) {
                maior = jogador.getpontuacao();
                resposta_final = ui.vencedor(jogador, maior);
            }
        }
        System.out.println(resposta_final+".");
    }
    public boolean jogar_novamente(List<Jogador> jogadores){
        ui.jogar_novamente();
        String entrada = input.nextLine().toUpperCase();
        char resposta_jogar_novamente = entrada.charAt(0);
        if (resposta_jogar_novamente != 'S') {
            ui.finalizar_jogo();
            return true;
        } else {
            ui.continuar_jogadores();
            entrada = input.nextLine().toUpperCase();
            char resposta_para_os_mesmos_jogadores = entrada.charAt(0);
            if (resposta_para_os_mesmos_jogadores != 'S') {
                jogadores.clear();
            }
            return false;
        }
    }

    public void dar_Carta(List<Jogador> jogadores, Baralho baralho) {
        for(Jogador jogador : jogadores) {
            Carta cartas_iniciais = baralho.tirarCarta();
            jogador.setCarta(cartas_iniciais);
            cartas_iniciais = baralho.tirarCarta();
            jogador.setCarta(cartas_iniciais);
        }

    }
    public int rodadas(){
        ui.rodadas();
        int rodadas;
        do{
            try{
                rodadas=Integer.parseInt(input.nextLine());
            }catch(Exception ex){
                rodadas=0;
            }
        }while(!entrada_maior_que(rodadas,0,"Como você irá jogar esse número de rodadas?\n Reescreva o número de rodadas:"));
        return rodadas;
    }
    public boolean entrada_maior_que(int entrada,int parametro,String saida){
        if (entrada>parametro){
            return true;
        }
        ui.entrada_invalida(saida);
        return false;
    }

}
