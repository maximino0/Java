package Terceiro;
import java.util.Random;
import java.util.Scanner;
public class Principal {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner input = new Scanner(System.in);
        int[][] vet= new int[3][];
        vet[0]= new int[2];
        vet[1]= new int[3];
        vet[2]= new int[5];
        for(int i=0;i< vet.length;i++){
            for(int cont=0;cont< vet[i].length;cont++){
                vet[i][cont]=random.nextInt(100);
            }
        }
        for(int[] numeros:vet){
            for(int numero:numeros){
                System.out.println(numero);
            }
        }
    }
}
