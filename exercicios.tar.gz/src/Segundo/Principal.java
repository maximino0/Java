package Segundo;
import java.util.Scanner;
public class Principal {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
    Object[][] filmes = new Object[2][3];
    for(int contador=0;contador< filmes.length;contador++) {
            System.out.println("Filme"+(contador+1)+": ");
            filmes[contador][0]= input.nextLine();
            System.out.println("Ano"+(contador+1)+":");
            filmes[contador][1]= Integer.parseInt(input.nextLine());
            System.out.println("Diretor"+(contador+1)+":");
            filmes[contador][2]= input.nextLine();
    }
    for(Object[] carac : filmes){
        System.out.println("============================");
        System.out.println("Filme:"+carac[0]);
        System.out.println("Ano:"+carac[1]);
        System.out.println("Diretor:"+carac[2]);
        System.out.println("============================");
    }
    }
}
