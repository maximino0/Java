package Primeiro;
import java.util.Scanner;
public class Principal {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int tamanho = 10;
        String vet[] = new String[tamanho];
        for(int i=0; i<vet.length;i++){
             vet[i]= input.nextLine();
        }
        for(String nome : vet){
             System.out.println(nome);
        }

    }
}
