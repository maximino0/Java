package br.edu.ifsp.spo.java.cards;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.*;

public class Jogo {

    public void Jogo(){
        Scanner input = new Scanner(System.in);
        List<Valor> verificar = new ArrayList<>();
        for (var rank : Valor.values()) {
            verificar.add(rank);
        }

        String resposta = "nada"; // Valor default caso o tempo acabe ou ocorra um erro
        Baralho baralho = new Baralho();
        boolean fim = true;
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Future<String> future = executor.submit(() -> input.nextLine().trim());
        while (fim) {
            for (Valor i : verificar) {
                Carta carta = baralho.tirarCarta();
                System.out.println("Essas cartas são iguais: " + carta.getValor() + " : " + i);

                // Usar um Future para tentar capturar a entrada dentro do tempo


                try {
                    // Espera no máximo 2 segundos pela entrada do jogador
                    resposta = future.get(2, TimeUnit.SECONDS);
                } catch (Exception e) {
                    // Caso o tempo expire ou ocorra algum erro, resposta fica "nada"
                    resposta = "nada"; // Garantir que "nada" seja o valor se o tempo expirar
                }

                // Agora, verificar a resposta e agir se for uma resposta válida
                if (resposta.equals("1") || resposta.equals("2")) {
                    fim = false;
                    if (carta.getValor().equals(i)) {
                        if (resposta.equals("1")) {
                            System.out.println("O jogador 1 venceu");
                        } else {
                            System.out.println("O jogador 2 venceu");
                        }
                    } else {
                        if (resposta.equals("1")) {
                            System.out.println("O jogador 1 perdeu");
                        } else {
                            System.out.println("O jogador 2 perdeu");
                        }
                    }
                    break; // Sai do loop assim que uma decisão for tomada
                }
            }
        }

        input.close();
        executor.shutdown();
    }
}
