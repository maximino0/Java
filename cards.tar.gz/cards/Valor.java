package br.edu.ifsp.spo.java.cards;

public enum Valor {
    AS, DOIS, TRES, QUATRO, CINCO, SEIS, SETE, OITO, NOVE, DEZ, DAMA, VALETE, REI;
}
