package br.edu.ifsp.spo.java.cards;

import java.util.List;

public class Jogador {

        private final String player1;
        private final List<Carta> carta;

        public Jogador(String nome, List<Carta> carta){
            this.player1 = nome;
            this.carta = carta;
        }
        public String getjogador(){return player1;}

    @Override
    public String toString() {
        return "Jogador{" +
                "player1='" + player1 + carta +'\'' +
                '}';
    }
}
