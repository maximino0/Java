//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.itens.Valor;
import br.edu.ifsp.spo.java.cards.nucleo.Jogador;

import java.util.Collections;
import java.util.List;
import java.util.Optional;


public class Pontuador {


    public int valoresVinteEUm(Valor entrada, int soma) {
        switch (entrada) {
            case AS:
                if (soma > 10) {
                    ++soma;
                } else {
                    soma += 11;
                }
                break;
            case DOIS:
                soma += 2;
                break;
            case TRES:
                soma += 3;
                break;
            case QUATRO:
                soma += 4;
                break;
            case CINCO:
                soma += 5;
                break;
            case SEIS:
                soma += 6;
                break;
            case SETE:
                soma += 7;
                break;
            case OITO:
                soma += 8;
                break;
            case NOVE:
                soma += 9;
                break;
            case DEZ:
            case DAMA:
            case VALETE:
            case REI:
                soma += 10;
        }

        return soma;
    }

    public boolean verificar_mao(Jogador jogador) {
        int soma = jogador.getSoma();
        if (soma > 21) {
            Utils util = new Utils();
            System.out.println(jogador.getjogador() + " a soma das suas cartas passou o limite de 21: " + soma);
            util.take_Time(1);
            jogador.setSoma(-5);
            return true;
        } else {
            return false;
        }
    }
    public int pontuacao(List<Carta> cartas){
        int soma = 0;
        for(Carta valor : Optional.ofNullable(cartas).orElse(Collections.emptyList())) {
            soma = valoresVinteEUm(valor.valor(), soma);
        }
        return soma;
    }
}
