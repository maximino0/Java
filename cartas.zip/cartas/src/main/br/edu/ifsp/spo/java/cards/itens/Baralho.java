//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.itens;

import br.edu.ifsp.spo.java.cards.App;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baralho {
    private final List<Carta> cartas = new ArrayList<>();

    public Baralho() {
        for(Naipe suit : Naipe.values()) {
            for(Valor rank : Valor.values()) {
                this.cartas.add(new Carta(suit, rank));
            }
        }

        Collections.shuffle(this.cartas);
    }

    public Carta tirarCarta() {
        return this.cartas.removeFirst();
    }

    public int cartasRestantes() {
        return this.cartas.size();
    }

    public String toString() {
        return "Deck{cards=" + this.cartasRestantes() + "}";
    }

    public List<Carta> getCards() {
        return this.cartas;
    }

    public String MostrarCartas(List<Carta> cartas) {
        var linhas = new String[7];
        var linhaAtual = -1;
        int contador_de_cartas =0;
        String resposta = "";
            for (Carta carta : cartas) {
                var caminhoCompleto = String.format(
                        "/cards/%s/%s.txt",
                        carta.naipe().toString(),
                        carta.valor().toString()
                );
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(App.class.getResourceAsStream(caminhoCompleto)))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        linhaAtual += 1;
                        if (linhas[linhaAtual] == null) {
                            linhas[linhaAtual] = line;
                        } else {
                            linhas[linhaAtual] = linhas[linhaAtual] + "   " + line;
                        }
                    }
                    contador_de_cartas+=1;
                    linhaAtual = -1;

                } catch (IOException exception) {
                    System.out.println("IOException: " + exception.getMessage());
                }

            }
            int minimo = 0;
            int regra=70;
            int cartas_renderizadas=0;
            while(true){
                int contador = 0;
                cartas_renderizadas+=5;
                while(true){
                    if(contador==6){
                        minimo+=70;
                        regra+=70;
                        break;
                    }
                    if(regra>linhas[contador].length()){regra=linhas[contador].length();}
                    String linha = linhas[contador].substring(minimo,regra);
                    resposta += "\n" + linha;
                    contador++;
                }
                resposta+="\n";
                if(cartas_renderizadas>=contador_de_cartas){
                    break;
                }
            }
        System.out.println(resposta);
        return resposta;
    }
}
