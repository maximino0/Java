
package br.edu.ifsp.spo.java.cards;


import br.edu.ifsp.spo.java.cards.itens.Baralho;
import br.edu.ifsp.spo.java.cards.nucleo.Jogo;


public class App {
    public App() {
    }

    public static void main(String[] args) {
//        Jogo jogo = new Jogo();
//        jogo.Jogo();
        Baralho baralho = new Baralho();
        baralho.MostrarCartas(baralho.getCards());
    }

}
