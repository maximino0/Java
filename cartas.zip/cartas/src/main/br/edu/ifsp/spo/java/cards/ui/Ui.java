package br.edu.ifsp.spo.java.cards.ui;

import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
import br.edu.ifsp.spo.java.cards.nucleo.JogadorIA;

import java.util.List;

public class Ui {
    public void comprar_Carta(Jogador jogador, int soma){
        System.out.println(jogador.getjogador() + ", a soma das suas cartas é: " + soma + " pois você tem " + printar_Cartas(jogador.getCarta())+".");
        if (!(jogador instanceof JogadorIA)){
            System.out.println( "\n Deseja comprar mais uma carta? S/N");
        }
    }
    public String printar_Cartas(List<Carta> cartas){
        String resultado = "";
        for (Carta carta : cartas){
            resultado += " \n " + carta.toString() ;
        }
        return resultado;
    }
    public void tirar_Carta(Carta carta,Jogador jogador){

        System.out.println(jogador.getjogador()+" tirou a carta: " + carta);
    }

    public String soma_final(Jogador jogador, int soma){
        return jogador.getjogador() + " a soma final das suas cartas é: " + soma;
    }

    public String passar_Vez(String resposta){
        return resposta + "\n Vez do próximo jogador.";
    }

    public String vencedor(Jogador jogador, int maior){
        return "O jogador " + jogador.getjogador() + " ganhou essa partida com " + maior + " pontos";
    }

    public String empate(Jogador jogador, int maior,String resposta){
        return resposta + ", Mas o jogador " + jogador.getjogador() + " também ganhou com " + maior + " pontos";
    }

    public void jogar_novamente(){
        System.out.println("Você deseja jogar outra vez? S/N");
    }

    public void finalizar_jogo(){
        System.out.println("Ok, jogo finalizado.");
    }

    public void continuar_jogadores(){
        System.out.println("Você deseja jogar com os mesmos jogadores: S/N \n");
    }

    public void rodadas(){
        System.out.println("Quantas rodadas terá o jogo? ");
    }

    public void rodada_jogada(int i){
        i=i+1;
        System.out.println("Rodada "+i+":");
    }
    public void mostrar_pontuacao(String entrada){
        System.out.println("Pontuacao da "+entrada+":");
    }

    public void pontuacao(List<Jogador> jogadores){
        jogadores.sort((Jogador jogador1, Jogador jogador2) -> Integer.compare(jogador2.getpontuacao(), jogador1.getpontuacao()));
        for(Jogador jogador : jogadores){
            System.out.println(jogador.getjogador() +":"+jogador.getpontuacao()+" pontos.");
        }
        System.out.println("\n");
    }

    public void entrada_invalida(String entrada){

        System.out.println(entrada);
    }
}
