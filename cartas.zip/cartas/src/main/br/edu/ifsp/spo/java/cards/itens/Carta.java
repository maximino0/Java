//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package br.edu.ifsp.spo.java.cards.itens;

public record Carta(Naipe naipe, Valor valor) {

    public String toString() {
        return this.valor() + " de " + this.naipe();
    }

    public boolean equals(Object o) {
        if (o != null && this.getClass() == o.getClass()) {
            Carta carta = (Carta) o;
            return this.naipe == carta.naipe && this.valor == carta.valor;
        } else {
            return false;
        }
    }
}
