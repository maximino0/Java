package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
import br.edu.ifsp.spo.java.cards.ui.Ui;

import java.util.List;

public class Rodada {
    public void pontuacao(List<Jogador> jogadores) {
        jogadores.sort((Jogador jogador1, Jogador jogador2) -> Integer.compare(jogador2.getSoma(), jogador1.getSoma()));
        int aux = 1;
        for (Jogador jogador : jogadores) {
            if (jogador.getSoma() == 21) {
                jogador.setSoma(30);
            }
            if (aux == 3) {
                break;
            }
            aux++;
        }
        for (int i = condicao_pontuacao(jogadores.size()); i < jogadores.size(); i++) {
            if (jogadores.get(i).getSoma() != -5 && jogadores.get(i).getSoma() != jogadores.get(condicao_pontuacao(jogadores.size())).getSoma()) {
                jogadores.get(i).setSoma(0);
            }
        }
        for (Jogador jogador : jogadores) {
            jogador.setpontuacao(jogador.getpontuacao()+jogador.getSoma());
        }
    }
    public int condicao_pontuacao(int entrada){
        if(entrada == 4 | entrada == 3){
            return 1;
        } else if (entrada >= 5) {
            return 2;
        } else {
            return 0; // valor padrão para outros casos, se necessário
        }
    }
    public int winner(List<Jogador> jogadores) {
        Ui ui = new Ui();
        int maior = 0;
        int retorno=0;
        String resposta_final = "Todos os jogadores perderam";
        for (Jogador jogador : jogadores) {
            if (jogador.getpontuacao() == maior && jogador.getpontuacao() > 0) {
                resposta_final = ui.empate(jogador, maior, resposta_final);
                retorno= 3;
            } else if (jogador.getpontuacao() > maior) {
                retorno=1;
                maior = jogador.getpontuacao();
                resposta_final = ui.vencedor(jogador, maior);
            }
        }
        final int maior_final = maior;
        if(retorno==3) retorno = (int)jogadores.stream().filter(j -> j.getpontuacao() == maior_final).count();
        System.out.println(resposta_final+".");
        return retorno;
    }
}
