package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class RodadaTest {
    List<Jogador> CriarJogadores(int quantidade){
        List<Jogador> jogadores = new ArrayList<Jogador>();
        for(int i=1;i<=quantidade;i++){
            jogadores.add(new Jogador("test dumb"+i));
        }
        return jogadores;
    }
    @Test
    void EmpateGeral(){
        Rodada rodada = new Rodada();
        List<Jogador> jogadores = CriarJogadores(5);
        for(Jogador jogador : jogadores){
            jogador.setSoma(10);
        }
        jogadores.getFirst().setSoma(9);
        rodada.pontuacao(jogadores);
        int resposta = rodada.winner(jogadores);
        assertEquals(4,resposta);
    }
    @Test
    void VitoriaGeral(){
        Rodada rodada = new Rodada();
        List<Jogador> jogadores = CriarJogadores(2);
        for(Jogador jogador : jogadores){
            jogador.setSoma(10+jogadores.indexOf(jogador));
        }
        rodada.pontuacao(jogadores);
        int resposta = rodada.winner(jogadores);
        assertEquals(1,resposta);
    }
    @Test
    void DerrotaGeral(){
        Rodada rodada = new Rodada();
        List<Jogador> jogadores = CriarJogadores(2);
        for(Jogador jogador : jogadores){
            jogador.setSoma(0);
        }
        rodada.pontuacao(jogadores);
        int resposta = rodada.winner(jogadores);
        assertEquals(0,resposta);
    }
}
