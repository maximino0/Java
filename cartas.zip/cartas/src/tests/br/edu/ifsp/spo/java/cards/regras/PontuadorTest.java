package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PontuadorTest {

    @Test
    void verificarMaoNula() {
        Pontuador pontuador = new Pontuador();
        List<Carta> cartas = null;
        var pontuacao_obtida = pontuador.pontuacao(cartas);
        assertEquals(0,pontuacao_obtida);
    }

    @Test
    void verificarSomaMaiorQue21() {
        Pontuador pontuador = new Pontuador();
        Jogador jogador = new Jogador("test dumb 1");
        jogador.setSoma(32);
        var resposta_obtida = pontuador.verificar_mao(jogador);
        assertTrue(resposta_obtida);
    }

    @Test
    void verificarSomaMenorQue21() {
        Pontuador pontuador = new Pontuador();
        Jogador jogador = new Jogador("test dumb 2");
        jogador.setSoma(21);
        var resposta_obtida = pontuador.verificar_mao(jogador);
        assertFalse(resposta_obtida);
    }
}